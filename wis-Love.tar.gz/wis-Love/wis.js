MoreWindows
=copy relative path
HashChangeEvent
github.path
github PageTransitionEvent
github-PluginArray
PageTransitionEvent
github.path function console.log(github.pages);