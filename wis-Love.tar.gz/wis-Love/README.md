https://vscode.dev/github/MyloCyrus/wis/blob/a6759f9636f6c175ec6336ef72a8b96f9b369dce# wis
This is the MASTER ROOT CODE FOR .JSON and .JS
add-remove compliance issues
Share and shaee alike you did not see this
